from grub import grub_objfun
import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint
from scipy.optimize import differential_evolution
import matplotlib.pyplot as plt


def runoptimization(params):

    objhist = []
    # plt.ion()
    # plt.show()

    joint = grub_objfun(100)

    def objcon(x):
        nonlocal objhist
        l = x[0]
        d_seg = np.array([x[1],x[2]])
        # d_seg = np.array([1])
        # print("l: ",l)
        # print("d_seg: ",d_seg)

        f = joint.get_f(d_seg,l)

        #for nelder-mead
        if x[0] < 0:
            f = f+10000*x[0]**2
        if x[0] > 1:
            f = f+10000*x[0]**2
        mu = 10000000
        g_pm = x[1]+x[2]-1
        f = f+mu/2*g_pm**2


        # print("f: ",f)
        g = np.zeros(1)
        g[0] = x[1]+x[2]-1
        objhist.append(f)

        # plt.semilogy(objhist)
        # plt.draw()
        # plt.pause(0.001)
        return f,g

    #------------- don't change -----------

    xlast = []
    flast = []
    glast = []

    def obj(x):
        nonlocal xlast, flast, glast
        if not np.array_equal(x,xlast):
            flast, glast = objcon(x)
            xlast = x
        return flast

    def con(x):
        nonlocal xlast, flast, glast
        if not np.array_equal(x,xlast):
            flast, glast = objcon(x)
            xlast = x
        return glast
    def seeing(xk,convergence=1):
        plt.semilogy(objhist,'b')
        plt.draw()
        plt.xlabel('Function_calls')
        plt.ylabel('Objective Function')
        plt.pause(0.001)


    # ---------------------------------------

    x0 = np.array([.9,.5,.5])
    # x0 = np.array([.1,.4,.6])
    lb = np.array([.01,0.,0.])
    ub = np.array([1.,1.,1.])
    lg = np.array([0.])
    ug = np.array([0.])

    # constraints = {'type': 'ineq', 'fun': con}
    constraints = NonlinearConstraint(con,lg,ug,jac='3-point')
    # options  = {'disp': True}
    options  = {'disp': True,'maxiter': 10000, 'verbose': 2}
    bounds=Bounds(lb,ub,keep_feasible=True)

    nlc = NonlinearConstraint(con,lg,ug)

    # res = minimize(obj, x0, jac='3-point', constraints=constraints, options=options, bounds=bounds, method='trust-constr') #SLSQP
    # res = minimize(obj, x0, jac='3-point', constraints=constraints, options=options, bounds=bounds, method='Nelder-Mead') #SLSQP
    res = differential_evolution(obj, bounds, callback=seeing, constraints=nlc,seed=1)
    print("x = ",res.x)
    print("f = ",res)
    print(res.success)

    plt.savefig("evolutionary.png") #, dpi=None, facecolor='w', edgecolor='w',
    #     orientation='portrait', papertype=None, format=None,
    #     transparent=False, bbox_inches=None, pad_inches=0.1,
    #     frameon=None, metadata=None)

    return res.x, res.fun, objhist

if __name__ == "__main__":
    params = []
    xstar,fstar, objhist = runoptimization(params)

    print("xstar: ",xstar)
    print("fstar: ",fstar)
    
    plt.figure()
    plt.semilogy(objhist)
    
    plt.xlabel('Function_calls')
    plt.ylabel('Objective Function')
    # plt.savefig("nelder_mead.png")
    plt.show()
    
    
    # from IPython import embed; embed()